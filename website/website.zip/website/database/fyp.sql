-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 16, 2024 at 02:59 AM
-- Server version: 10.4.28-MariaDB
-- PHP Version: 8.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bookflixdb`
--
CREATE DATABASE IF NOT EXISTS `bookflixdb` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `bookflixdb`;

-- --------------------------------------------------------

--
-- Table structure for table `book_info`
--

CREATE TABLE `book_info` (
  `bid` int(100) NOT NULL,
  `name` varchar(20) NOT NULL,
  `title` varchar(20) NOT NULL,
  `price` decimal(10,0) NOT NULL,
  `category` varchar(50) NOT NULL,
  `description` text NOT NULL,
  `image` varchar(10) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `book_info`
--

INSERT INTO `book_info` (`bid`, `name`, `title`, `price`, `category`, `description`, `image`, `date`) VALUES
(72, 'Atomic Habits', 'James C', 699, 'knowledge', 'Her imaginative childrens books feature many natural animals that can be found in the British countryside', 'ah.png', '2023-02-23 13:14:49'),
(81, 'Darwin', 'Darwin D.', 469, 'knowledge', 'Beatrix Potter ', 'sddxc.jpg', '2023-02-24 10:54:38'),
(83, 'Capture The Crown ', 'Jennifer E.', 633, 'Magic', 'From the author of The Witch Boy trilogy comes a graphic novel about family, romance, and first love', 'gf.jpg', '2023-02-24 10:56:14'),
(84, 'Crush The King ', 'Jennifer L', 566, 'knowledge', 'These stories are carefully chosen to highlight the power of the gods and how sometimes the demons challenge it. The stories are narrated in a way that would be suitable for children and ensures small moral lessons in each story. Children will learn that there are no short cuts to success, and our confidence is our biggest super power.', 'uuh.jpg', '2023-02-24 10:58:12'),
(85, 'Stephen King', 'Carre', 545, 'Adventure', 'The political struggle in the ancient city of Hastinapur is escalating as the Pandavas and Kauravas are on the verge of war. But its the rise of the demonic Asura King, Mahendrasura, that most troubles Krishna. Fueled by vengeance, Mahendrasura is not looking to just win a battle. Instead, he in search of dark powers to eradicate humanity once and for all.', 'FGGH.jpg', '2023-02-24 10:58:53'),
(86, 'The Winter King', 'Christ C', 65, 'knowledge', 'Trapped in an era beyond his wildest dreams, Abhay has managed to land right in the middle of all these conflicts. Along with Krishna and Suryaputra Karna, the responsibility to save the past, the present, and the future of mankind has fallen on Abhays shoulders. And for that, he must unlock ancient puzzles, encounter mythical beasts - and confront his terrifying destiny!', 'ghfh.jpg', '2023-02-24 10:59:29'),
(88, 'Ray Bearer', 'Jordan I.', 999, 'Magic', 'Once upon a time there were four little Rabbits, and their names were -- ', 'jjj.jpg', '2023-02-24 11:05:00'),
(89, 'The Sea Girl', 'Adriene ', 699, '', 'From the authovel about family, romance, and first love. ', 'jhj.jfif', '2023-02-24 11:07:51'),
(90, 'Love Boat', 'Abile Hing', 499, 'Adventure', 'Feel the power of strength and banding together come alive through the celebration of our very own female animal characters in Lili the Lioness & Friends. Written, designed and produced in-house, this impactful read highlights the importance of community ', 'jkkj.jpg', '2023-02-24 11:25:52'),
(93, 'Seventh Sun', ' Lani Forbes', 560, 'Magic', 'The terrible Asuras are pretty notorious. These demons have decided to spread chaos across the world and win over heaven. Here comes an Asura trying to kidnap mother Earth', 'kjljl.jpg', '2023-02-24 11:55:58'),
(94, 'Sunrise', 'Jhon D', 800, 'Magic', 'Charming but venturesome college student, Abhay Sharma, always thought the Mahabharata was just a story; until he set out to explore the secrets of an ancient temple – and finds himself transported five thousand years back in time!', 'hujh.jpg', '2023-02-24 11:57:02'),
(95, 'Batman Knight', 'DC', 789, 'Adventure', 'This collection of adorable stories for children show us how the Asuras tried to defeat the Devas, and how the gods ultimately won over. These stories will entertain, educate and provide healthy enjoyment to the readers.', 'kjkjl.jpg', '2023-02-24 11:59:54'),
(96, 'Last Blood ', 'Alexander G', 500, '', 'The political struggle in the ancient city of Hastinapur is escalating as the Pandavas and Kauravas are on the verge of war. But its the rise of the demonic Asura King, Mahendrasura, that most troubles Krishna. Fueled by vengeance, Mahendrasura is not looking to just win a battle. Instead, he in search of dark powers to eradicate humanity once and for all.', 'hjhj.jpg', '2023-02-24 12:12:30');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `id` int(100) NOT NULL,
  `book_id` int(20) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  `price` int(20) NOT NULL,
  `image` varchar(25) NOT NULL,
  `quantity` int(25) NOT NULL,
  `total` double(10,2) NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `cart`
--

INSERT INTO `cart` (`id`, `book_id`, `user_id`, `name`, `price`, `image`, `quantity`, `total`, `date`) VALUES
(162, 96, 51, 'Last Blood ', 499, 'hjhj.jpg', 3, 1.00, '2023-03-10 14:44:26'),
(163, 96, 56, 'Last Blood ', 500, 'hjhj.jpg', 1, 500.00, '2024-03-16 00:11:50');

-- --------------------------------------------------------

--
-- Table structure for table `confirm_order`
--

CREATE TABLE `confirm_order` (
  `order_id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `number` int(12) NOT NULL,
  `address` varchar(500) NOT NULL,
  `payment_method` varchar(20) NOT NULL,
  `total_books` varchar(500) NOT NULL,
  `order_date` varchar(100) NOT NULL,
  `payment_status` varchar(100) NOT NULL DEFAULT 'pending',
  `date` varchar(20) NOT NULL,
  `total_price` double(10,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `confirm_order`
--

INSERT INTO `confirm_order` (`order_id`, `user_id`, `name`, `email`, `number`, `address`, `payment_method`, `total_books`, `order_date`, `payment_status`, `date`, `total_price`) VALUES
(31, 51, 'rtyrty', 'pawan@gmail.coma', 0, 'yey, brtb, hrthgeg,  6ygege - 6546', 'cash on delivery', ' pawan #46,(1)  yukuyk #44,(1)  sdfsd #54,(1) ', '24-Feb-2023', 'completed', '24.02.2023', 7102.00),
(32, 51, 'dsdd', 'pawan@gmail.coma', 2147483647, 'hrthgerg, 747hfh, brt,  ygege - 6546', 'Debit card', ' iuji #89,(1)  Ray Bearer #88,(1) ', '24-Feb-2023', 'completed', '10.03.2023', 6424.00);

-- --------------------------------------------------------

--
-- Table structure for table `msg`
--

CREATE TABLE `msg` (
  `id` int(100) NOT NULL,
  `user_id` int(100) NOT NULL,
  `name` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `number` int(20) NOT NULL,
  `msg` text NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `msg`
--

INSERT INTO `msg` (`id`, `user_id`, `name`, `email`, `number`, `msg`, `date`) VALUES
(6, 51, 'pawan ', 'pawan@gmail.com', 2147483647, 'MOST DANGEROUS GAME AND OTHER STORIES OF ADVENTURE, THE \r\n\r\nis there availability', '2023-02-23 13:41:50'),
(7, 51, 'dfbgf', 'hdgfh@vszv', 0, 'dh', '2023-02-23 13:47:26'),
(8, 51, 'sv', 'jisaxih205@minterp.c', 0, 'xhf', '2023-02-23 13:49:56');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(225) NOT NULL,
  `user_id` int(100) NOT NULL,
  `address` varchar(50) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(50) NOT NULL,
  `country` varchar(50) NOT NULL,
  `pincode` int(6) NOT NULL,
  `book` varchar(50) NOT NULL,
  `unit_price` double(10,2) NOT NULL,
  `quantity` int(10) NOT NULL,
  `sub_total` double(10,2) NOT NULL,
  `payment_status` varchar(100) NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `user_id`, `address`, `city`, `state`, `country`, `pincode`, `book`, `unit_price`, `quantity`, `sub_total`, `payment_status`) VALUES
(0, 51, 'yey', '747hfh', 'eyy', 'tutututu', 6546, 'yukuyk', 56778.00, 1, 56778.00, 'completed'),
(0, 51, 'yey', '747hfh', 'eyy', 'tutututu', 6546, 'Don Quixote by Migue', 2555.00, 6, 15330.00, 'pending'),
(0, 51, 'yey', 'yery', 'eyy', 'erge', 0, 'yukuyk', 56778.00, 1, 56778.00, 'pending'),
(0, 51, 'hrth', 'hrt', 'hrth', ' 6y', 0, 'Don Quixote by Migue', 2555.00, 1, 2555.00, 'pending'),
(0, 51, 'hrthgerg', 'hrtgeg', 'hrthgeg', ' 6ygege', 0, 'Don Quixote by Migue', 2555.00, 1, 2555.00, 'pending'),
(0, 51, 'hrthgerg', '747hfh', 'hgfyj', ' 6ygege', 0, 'fhb', 5124.00, 1, 5124.00, 'pending'),
(0, 51, 'yey', 'yery', 'hgfyj', 'erge', 0, 'Don Quixote by Migue', 2555.00, 1, 2555.00, 'pending'),
(0, 51, '4747', '747hfh', 'hrthgeg', 'tutututu', 6546, 'Don Quixote by Migue', 2555.00, 1, 2555.00, 'pending'),
(0, 51, '4747', '747hfh', 'hrthgeg', 'tutututu', 6546, 'Don Quixote by Migue', 2555.00, 1, 2555.00, 'pending'),
(0, 51, 'hrthgerg', '747hfh', 'eyy', 'wfrwerfw', 0, 'Don Quixote by Migue', 2555.00, 1, 2555.00, 'pending'),
(21, 51, '4747', '747hfh', 'hgfyj', 'yey', 6546, 'Don Quixote by Migue', 2555.00, 1, 2555.00, 'pending'),
(21, 51, '4747', '747hfh', 'hgfyj', 'yey', 6546, 'yukuyk', 56778.00, 1, 56778.00, 'pending'),
(24, 51, 'hrthgerg', '747hfh', 'eyy', 'tutututu', 6546, 'grwe', 45.00, 1, 45.00, 'pending'),
(24, 51, 'hrthgerg', '747hfh', 'eyy', 'tutututu', 6546, 'yukuyk', 56778.00, 1, 56778.00, 'pending'),
(24, 51, 'hrthgerg', '747hfh', 'eyy', 'tutututu', 6546, 'pawan', 4141471.00, 1, 4141471.00, 'pending'),
(24, 51, 'hrthgerg', '747hfh', 'eyy', 'tutututu', 6546, 'pawan', 25252.00, 1, 25252.00, 'pending'),
(24, 51, 'hrthgerg', '747hfh', 'eyy', 'tutututu', 6546, 'fhb', 5124.00, 1, 5124.00, 'pending'),
(24, 51, 'hrthgerg', '747hfh', 'eyy', 'tutututu', 6546, 'Don Quixote by Migue', 2000.00, 1, 2000.00, 'pending'),
(24, 51, 'hrthgerg', '747hfh', 'eyy', 'tutututu', 6546, 'Don Quixote by Migue', 2555.00, 1, 2555.00, 'pending'),
(25, 51, 'f3f3', 'f34f', 'f3f', 'f3f', 0, 'pawan', 122.00, 1, 122.00, 'pending'),
(26, 51, 'brtbr', 'brtb', 'brt', 'bb', 0, 'pawan', 4141471.00, 1, 4141471.00, 'pending'),
(27, 51, 'nttnnht', 'nfnfghn', 'nghngh', 'ghng', 0, 'pawan', 122.00, 1, 122.00, 'pending'),
(27, 51, 'nttnnht', 'nfnfghn', 'nghngh', 'ghng', 0, 'yukuyk', 6545.00, 1, 6545.00, 'pending'),
(27, 51, 'nttnnht', 'nfnfghn', 'nghngh', 'ghng', 0, 'yukuyk', 56778.00, 1, 56778.00, 'pending'),
(28, 51, 'wtwtw', 'twet', 'wtwet', 'twet', 0, 'pawan', 122.00, 4, 488.00, 'pending'),
(29, 51, 'hrthgerg', '747hfh', 'hrthgeg', 'tutututu', 6546, 'Don Quixote by Migue', 2000.00, 1, 2000.00, 'pending'),
(29, 51, 'hrthgerg', '747hfh', 'hrthgeg', 'tutututu', 6546, 'v xvx', 45645.00, 1, 45645.00, 'pending'),
(29, 51, 'hrthgerg', '747hfh', 'hrthgeg', 'tutututu', 6546, 'fhb', 5124.00, 4, 20496.00, 'pending'),
(30, 51, 'hrthgerg', 'hrtgeg', 'hrthgeg', '85*94', 0, 'v xvx', 45645.00, 1, 45645.00, 'pending'),
(30, 51, 'hrthgerg', 'hrtgeg', 'hrthgeg', '85*94', 0, 'pawan', 122.00, 1, 122.00, 'pending'),
(31, 51, 'yey', 'brtb', 'hrthgeg', ' 6ygege', 6546, 'pawan', 122.00, 1, 122.00, 'pending'),
(31, 51, 'yey', 'brtb', 'hrthgeg', ' 6ygege', 6546, 'yukuyk', 6545.00, 1, 6545.00, 'pending'),
(31, 51, 'yey', 'brtb', 'hrthgeg', ' 6ygege', 6546, 'sdfsd', 435.00, 1, 435.00, 'pending'),
(32, 51, 'hrthgerg', '747hfh', 'brt', ' ygege', 6546, 'iuji', 5425.00, 1, 5425.00, 'pending'),
(32, 51, 'hrthgerg', '747hfh', 'brt', ' ygege', 6546, 'Ray Bearer', 999.00, 1, 999.00, 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `users_info`
--

CREATE TABLE `users_info` (
  `Id` int(100) NOT NULL,
  `name` varchar(20) NOT NULL,
  `surname` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `user_type` varchar(20) NOT NULL DEFAULT 'user'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users_info`
--

INSERT INTO `users_info` (`Id`, `name`, `surname`, `email`, `password`, `user_type`) VALUES
(51, 'pawan', 'pawan', 'pawan@gmail.com', '12345678', 'User'),
(52, 'pawan111', 'pawan111', 'pawan@gmail.com1', '12345678', 'Admin'),
(53, 'pawan', 'pawan', 'pawan@gmail.coma', '12345678', 'Admin'),
(56, 'junren', 'junren', 'jr@gmail.com', 'jr', 'User'),
(57, 'Jun Ren', 'Tan', 'asd@asd.com', 'asd', 'Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book_info`
--
ALTER TABLE `book_info`
  ADD PRIMARY KEY (`bid`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `confirm_order`
--
ALTER TABLE `confirm_order`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `msg`
--
ALTER TABLE `msg`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users_info`
--
ALTER TABLE `users_info`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `book_info`
--
ALTER TABLE `book_info`
  MODIFY `bid` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=97;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=164;

--
-- AUTO_INCREMENT for table `confirm_order`
--
ALTER TABLE `confirm_order`
  MODIFY `order_id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

--
-- AUTO_INCREMENT for table `msg`
--
ALTER TABLE `msg`
  MODIFY `id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `users_info`
--
ALTER TABLE `users_info`
  MODIFY `Id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;
--
-- Database: `cafe`
--
CREATE DATABASE IF NOT EXISTS `cafe` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `cafe`;
--
-- Database: `cafedb`
--
CREATE DATABASE IF NOT EXISTS `cafedb` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `cafedb`;

-- --------------------------------------------------------

--
-- Table structure for table `assignments`
--

CREATE TABLE `assignments` (
  `assignmentID` int(11) NOT NULL,
  `employeeID` int(11) NOT NULL,
  `workslotid` int(11) NOT NULL,
  `role` enum('chef','cashier','waiter') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `assignments`
--

INSERT INTO `assignments` (`assignmentID`, `employeeID`, `workslotid`, `role`) VALUES
(33, 12, 64, 'chef'),
(34, 2, 65, 'chef'),
(35, 12, 66, 'waiter'),
(36, 2, 67, 'cashier'),
(37, 12, 68, 'cashier'),
(38, 5, 69, 'cashier'),
(39, 5, 70, 'cashier'),
(40, 5, 71, 'cashier'),
(41, 5, 72, 'cashier'),
(42, 5, 73, 'chef'),
(43, 0, 74, 'cashier'),
(45, 5, 76, 'cashier'),
(50, 0, 81, 'chef'),
(51, 0, 82, 'chef');

-- --------------------------------------------------------

--
-- Table structure for table `bids`
--

CREATE TABLE `bids` (
  `bidID` int(11) NOT NULL,
  `employeeID` int(11) NOT NULL,
  `workslotid` int(11) NOT NULL,
  `bid_role` enum('chef','cashier','waiter') NOT NULL,
  `max_slots` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bids`
--

INSERT INTO `bids` (`bidID`, `employeeID`, `workslotid`, `bid_role`, `max_slots`) VALUES
(54, 2, 64, 'chef', 1),
(55, 2, 65, 'chef', 1),
(56, 2, 66, 'waiter', 1),
(57, 2, 67, 'cashier', 1),
(58, 5, 71, 'cashier', 1),
(59, 5, 69, 'cashier', 1),
(60, 5, 70, 'cashier', 1),
(61, 5, 72, 'cashier', 1),
(62, 5, 76, 'cashier', 1);

-- --------------------------------------------------------

--
-- Table structure for table `bidstatus`
--

CREATE TABLE `bidstatus` (
  `bidID` int(11) NOT NULL,
  `status` enum('approved','pending','rejected') NOT NULL,
  `feedback` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `bidstatus`
--

INSERT INTO `bidstatus` (`bidID`, `status`, `feedback`) VALUES
(54, 'pending', NULL),
(55, 'approved', ''),
(56, 'pending', NULL),
(57, 'pending', NULL),
(58, 'approved', ''),
(59, 'pending', NULL),
(60, 'pending', NULL),
(61, 'approved', ''),
(62, 'approved', 'OT');

-- --------------------------------------------------------

--
-- Table structure for table `employeemaxslots`
--

CREATE TABLE `employeemaxslots` (
  `employeeID` int(11) NOT NULL,
  `MaxSlotsPerWeek` int(11) DEFAULT NULL,
  `CurrentSlotsUsage` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `employeemaxslots`
--

INSERT INTO `employeemaxslots` (`employeeID`, `MaxSlotsPerWeek`, `CurrentSlotsUsage`) VALUES
(2, 2, 2),
(5, 10, 8),
(12, 10, 3);

-- --------------------------------------------------------

--
-- Table structure for table `mc_requests`
--

CREATE TABLE `mc_requests` (
  `request_id` int(11) NOT NULL,
  `employee_name` varchar(255) NOT NULL,
  `mc_details` text NOT NULL,
  `request_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `status` enum('Pending','Approved','Rejected') DEFAULT 'Pending',
  `mc_start_date` date DEFAULT NULL,
  `mc_end_date` date DEFAULT NULL,
  `deleted` tinyint(1) NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mc_requests`
--

INSERT INTO `mc_requests` (`request_id`, `employee_name`, `mc_details`, `request_date`, `status`, `mc_start_date`, `mc_end_date`, `deleted`) VALUES
(1, 'william', 'Flu', '2023-11-09 02:21:48', 'Approved', '2023-11-14', '2023-11-22', 0),
(2, 'emily', 'Fever', '2023-11-09 02:29:03', 'Approved', '2023-11-14', '2023-11-22', 0),
(3, 'Andrew', 'Cough', '2023-11-09 02:29:09', 'Approved', '2023-11-14', '2023-11-22', 0),
(4, 'olivia', 'Chao Keng', '2023-11-09 02:31:06', 'Pending', '2023-11-14', '2023-11-22', 0),
(5, 'jackson', 'Flu', '2023-11-09 02:35:13', 'Pending', '2023-11-14', '2023-11-22', 0),
(6, 'Andrew', 'Stomache', '2023-11-09 02:38:09', 'Pending', '2023-11-14', '2023-11-22', 0),
(7, 'emily', 'Flu', '2023-11-12 02:38:28', 'Pending', '2023-11-20', '2023-11-08', 0),
(8, 'emily', 'Flu', '2023-11-15 15:34:44', 'Pending', '2023-11-16', '2023-11-18', 0);

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `workslotid` int(11) NOT NULL,
  `employeeID` int(11) DEFAULT NULL,
  `date` date NOT NULL,
  `role` enum('chef','cashier','waiter') NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `status` enum('pending','accepted','rejected') NOT NULL DEFAULT 'pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`workslotid`, `employeeID`, `date`, `role`, `start_time`, `end_time`, `created_at`, `updated_at`, `status`) VALUES
(64, 12, '2023-11-23', 'chef', '03:29:00', '21:29:00', '2023-11-13 07:29:04', '2023-11-13 07:58:09', 'accepted'),
(65, 2, '2023-11-22', 'chef', '18:29:00', '08:29:00', '2023-11-13 07:29:25', '2023-11-13 08:03:39', 'accepted'),
(66, 12, '2023-11-29', 'waiter', '19:29:00', '03:34:00', '2023-11-13 07:29:32', '2023-11-13 08:01:17', 'accepted'),
(67, 2, '2023-11-22', 'cashier', '15:32:00', '15:29:00', '2023-11-13 07:29:40', '2023-11-13 07:53:55', 'accepted'),
(68, 12, '2023-11-16', 'cashier', '03:56:00', '20:01:00', '2023-11-13 07:56:27', '2023-11-13 08:01:13', 'accepted'),
(69, 5, '2023-12-05', 'cashier', '19:04:00', '16:10:00', '2023-11-13 08:04:28', '2023-11-13 08:20:06', 'accepted'),
(70, 5, '2023-12-01', 'cashier', '19:06:00', '04:04:00', '2023-11-13 08:04:37', '2023-11-13 08:12:11', 'accepted'),
(71, 5, '2023-11-30', 'cashier', '18:04:00', '08:04:00', '2023-11-13 08:04:46', '2023-11-13 08:05:37', 'accepted'),
(72, 5, '2023-11-09', 'cashier', '19:17:00', '16:23:00', '2023-11-13 08:17:07', '2023-11-13 08:18:06', 'accepted'),
(73, 5, '2023-11-23', 'chef', '16:22:00', '21:20:00', '2023-11-13 08:20:47', '2023-11-13 08:23:13', 'accepted'),
(74, 2, '2023-12-01', 'cashier', '14:21:00', '06:18:00', '2023-11-15 06:18:15', '2023-11-15 06:19:18', 'pending'),
(76, 5, '2024-01-01', 'cashier', '11:33:00', '23:34:00', '2023-11-15 15:34:01', '2023-11-15 15:35:16', 'accepted'),
(81, NULL, '2024-01-30', 'chef', '11:08:00', '17:06:00', '2023-11-17 03:06:42', '2023-11-17 03:06:42', 'pending'),
(82, NULL, '2023-11-23', 'chef', '11:42:00', '14:42:00', '2023-11-20 02:42:08', '2023-11-20 02:42:08', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `usersacc`
--

CREATE TABLE `usersacc` (
  `employeeID` int(11) NOT NULL,
  `username` text NOT NULL,
  `name` text NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` text NOT NULL,
  `password` text NOT NULL,
  `users_type` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `usersacc`
--

INSERT INTO `usersacc` (`employeeID`, `username`, `name`, `phone`, `email`, `password`, `users_type`) VALUES
(1, 'admin', 'Admin User', '123', 'admin@admin.com', '$2y$10$oXn/3ne3UzYG81cVqzM0seGqDZpcMqlXIglHqpSv3rwT7oZSOyA5y', 'SA'),
(2, 'staff', 'Andrew', '123', 'staff@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(3, 'manager', 'manager', '123', 'manager@manager.com', '$2y$10$u2cJ1tibpWlxQQfbTpbIeOfO0G7hgcvZ213GCRSC0d/EQpiMR7Cb6', 'CM'),
(4, 'owner', 'owner', '123', 'owner@owner.com', '$2y$10$m43N1u7c8gZzFbAxAYFzZekyInkavIXFGXBEs.3.QSUpqfLPNvZ8.', 'CO'),
(5, 'staff5', 'emily', '202', 'emily@staff.com', '$2y$10$Q82mCjeNhBpVuhUyLahUy.zvgFXLZFiyvwB74CnyM..OxiMIwQNca', 'CS'),
(6, 'staff6', 'michael', '303', 'michael@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(7, 'staff7', 'olivia', '404', 'olivia@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(8, 'staff8', 'jacob', '505', 'jacob@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(9, 'staff9', 'ava', '606', 'ava@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(10, 'staff10', 'william', '707', 'william@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(11, 'staff11', 'sophia', '808', 'sophia@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(12, 'staff12', 'jackson', '909', 'jackson@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(13, 'staff13', 'oliver', '111', 'oliver@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(14, 'staff14', 'amelia', '222', 'amelia@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(15, 'staff15', 'henry', '333', 'henry@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(16, 'staff16', 'mia', '444', 'mia@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(17, 'staff17', 'logan', '555', 'logan@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(18, 'staff18', 'harper', '666', 'harper@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(19, 'staff19', 'evelyn', '777', 'evelyn@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(20, 'staff20', 'abigail', '888', 'abigail@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(21, 'staff21', 'ryan', '999', 'ryan@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(22, 'staff22', 'grace', '121', 'grace@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(23, 'staff23', 'nathan', '232', 'nathan@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(24, 'staff24', 'lily', '343', 'lily@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(25, 'staff25', 'daniel', '454', 'daniel@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(26, 'staff26', 'charlotte', '565', 'charlotte@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(27, 'staff27', 'samuel', '676', 'samuel@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(28, 'staff28', 'victoria', '787', 'victoria@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(29, 'staff29', 'caleb', '898', 'caleb@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(30, 'staff30', 'zoe', '909', 'zoe@staff.com', '$2y$10$D.jFFqnwmNfujfvRvtS1s.iiZB1EJVW.nXDk.TABAKSXcaY6nfZgS', 'CS'),
(103, 'asd', 'asd1', 'asd', 'asd@asd.com', '$2y$10$iODHL0Zd6rJ0tng2xO4HdOi4dEkfsYMqJ/Rw57EzS4UqBUSCEDkBS', 'CS');

-- --------------------------------------------------------

--
-- Table structure for table `userstype`
--

CREATE TABLE `userstype` (
  `users_type` varchar(2) NOT NULL,
  `users_desc` varchar(5000) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `userstype`
--

INSERT INTO `userstype` (`users_type`, `users_desc`) VALUES
('CM', 'Manager'),
('CO', 'Owner'),
('CS', 'Staff Member'),
('SA', 'System Admin');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `assignments`
--
ALTER TABLE `assignments`
  ADD PRIMARY KEY (`assignmentID`),
  ADD KEY `employeeID` (`employeeID`),
  ADD KEY `workslotid` (`workslotid`);

--
-- Indexes for table `bids`
--
ALTER TABLE `bids`
  ADD PRIMARY KEY (`bidID`),
  ADD KEY `employeeID` (`employeeID`),
  ADD KEY `workslotid` (`workslotid`);

--
-- Indexes for table `bidstatus`
--
ALTER TABLE `bidstatus`
  ADD KEY `bidstatus_ibfk_1` (`bidID`);

--
-- Indexes for table `employeemaxslots`
--
ALTER TABLE `employeemaxslots`
  ADD PRIMARY KEY (`employeeID`);

--
-- Indexes for table `mc_requests`
--
ALTER TABLE `mc_requests`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`workslotid`),
  ADD KEY `schedule_ibfk_1` (`employeeID`);

--
-- Indexes for table `usersacc`
--
ALTER TABLE `usersacc`
  ADD PRIMARY KEY (`employeeID`),
  ADD KEY `fk_user_type` (`users_type`);

--
-- Indexes for table `userstype`
--
ALTER TABLE `userstype`
  ADD PRIMARY KEY (`users_type`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `assignments`
--
ALTER TABLE `assignments`
  MODIFY `assignmentID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=52;

--
-- AUTO_INCREMENT for table `bids`
--
ALTER TABLE `bids`
  MODIFY `bidID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=63;

--
-- AUTO_INCREMENT for table `mc_requests`
--
ALTER TABLE `mc_requests`
  MODIFY `request_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `workslotid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=83;

--
-- AUTO_INCREMENT for table `usersacc`
--
ALTER TABLE `usersacc`
  MODIFY `employeeID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=104;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `assignments`
--
ALTER TABLE `assignments`
  ADD CONSTRAINT `assignments_ibfk_2` FOREIGN KEY (`workslotid`) REFERENCES `schedule` (`workslotid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bids`
--
ALTER TABLE `bids`
  ADD CONSTRAINT `bids_ibfk_1` FOREIGN KEY (`employeeID`) REFERENCES `usersacc` (`employeeID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `bids_ibfk_2` FOREIGN KEY (`workslotid`) REFERENCES `schedule` (`workslotid`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `bidstatus`
--
ALTER TABLE `bidstatus`
  ADD CONSTRAINT `bidstatus_ibfk_1` FOREIGN KEY (`bidID`) REFERENCES `bids` (`bidID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `schedule`
--
ALTER TABLE `schedule`
  ADD CONSTRAINT `FK_Schedule_Employee` FOREIGN KEY (`employeeID`) REFERENCES `employeemaxslots` (`employeeID`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `schedule_ibfk_1` FOREIGN KEY (`employeeID`) REFERENCES `usersacc` (`employeeID`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `usersacc`
--
ALTER TABLE `usersacc`
  ADD CONSTRAINT `fk_user_type` FOREIGN KEY (`users_type`) REFERENCES `userstype` (`users_type`);
--
-- Database: `fitness`
--
CREATE DATABASE IF NOT EXISTS `fitness` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `fitness`;

-- --------------------------------------------------------

--
-- Table structure for table `service`
--

CREATE TABLE `service` (
  `ser_id` int(11) NOT NULL,
  `ser_name` varchar(50) NOT NULL,
  `ser_desc` varchar(100) NOT NULL,
  `ser_cap` int(11) NOT NULL,
  `ser_cost` decimal(10,2) NOT NULL,
  `ser_latecost` decimal(10,2) NOT NULL,
  `ser_availability` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `service`
--

INSERT INTO `service` (`ser_id`, `ser_name`, `ser_desc`, `ser_cap`, `ser_cost`, `ser_latecost`, `ser_availability`) VALUES
(1, 'cardio fitness', 'cardio', 100, 10.00, 15.00, 'Not Available'),
(2, 'functional fitness', 'functional', 60, 10.00, 15.00, 'Available'),
(3, 'tennis', 'tennis', 50, 10.00, 15.00, 'Available'),
(4, 'badminton', 'badminton', 70, 10.00, 15.00, 'Available'),
(5, 'yoga fitness', 'flexible', 80, 10.00, 15.00, 'Available'),
(6, 'test1', 'test1', 1, 10.00, 20.00, 'Available'),
(7, 'test2', 'test2', 2, 10.00, 20.00, 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `serviceslot`
--

CREATE TABLE `serviceslot` (
  `idserviceslot` int(11) NOT NULL,
  `username` varchar(45) NOT NULL,
  `service` varchar(45) NOT NULL,
  `checkin` varchar(45) NOT NULL,
  `datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `serviceslot`
--

INSERT INTO `serviceslot` (`idserviceslot`, `username`, `service`, `checkin`, `datetime`) VALUES
(1, 'User1', 'test1', 'Checked In', '2023-08-23 10:58:06'),
(2, 'User1', 'test2', 'Checked In', '2023-08-23 10:58:12'),
(3, 'User2', 'test1', 'Checked In', '2023-08-23 10:58:51'),
(4, 'User2', 'test2', 'Checked In', '2023-08-23 10:59:06');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `users_id` int(11) NOT NULL,
  `users_uid` text NOT NULL,
  `users_fname` text NOT NULL,
  `users_lname` text NOT NULL,
  `users_phone` varchar(20) NOT NULL,
  `users_email` text NOT NULL,
  `users_pwd` text NOT NULL,
  `users_type` varchar(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`users_id`, `users_uid`, `users_fname`, `users_lname`, `users_phone`, `users_email`, `users_pwd`, `users_type`) VALUES
(1, 'member1', 'member1', 'member1', '123', 'member1@member1.com', 'member1', 'M'),
(2, 'member2', 'member2', 'member2', '123', 'member2@member2.com', 'member2', 'M'),
(3, 'member3', 'member3', 'member3', '123', 'member3@member3.com', 'member3', 'M'),
(4, 'member4', 'member4', 'member4', '123', 'member4@member4.com', 'member4', 'M'),
(5, 'member5', 'member5', 'member5', '123', 'member5@member5.com', 'member5', 'M'),
(6, 'admin1', 'admin1', 'admin1', '123', 'admin1@admin1.com', 'admin1', 'A'),
(7, 'admin2', 'admin2', 'admin2', '123', 'admin1@admin2.com', 'admin2', 'A'),
(8, 'admin3', 'admin3', 'admin3', '123', 'admin1@admin3.com', 'admin3', 'A'),
(9, 'admin4', 'admin4', 'admin4', '123', 'admin1@admin4.com', 'admin4', 'A'),
(10, 'admin5', 'admin5', 'admin5', '123', 'admin1@admin5.com', 'admin5', 'A'),
(12, 'user1', 'user1', 'user1', '123', 'user1@use.rcom', '$2y$10$YiRjWvFBOLk24HUjMoyoTeU3sskmObYaVspR5NuGtSs6AKps.B/ui', 'M'),
(13, 'user2', 'USER2', 'USER2', '123', 'asd@asd.comm', '$2y$10$cgdto6lm7XmiQ1LEtcq3eO3sJ/aMyRG08hCYnE8skNW.sN6/19GgS', 'M'),
(14, 'asd', 'asd', 'asd', 'asd', 'asd@asd.com', '$2y$10$fFc1TmgLFryxif9tsRxSr.B8aFLuydDu5tPmiBYzY2obsJju9acwe', 'A'),
(15, 'admin', 'admin', 'admin', '123', 'admin@admin.com', '$2y$10$xeRNGdm4j3noUr2ygqbjcecVfzVowxbczaY3zuYJsAJpyGCgCH1ze', 'A');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `service`
--
ALTER TABLE `service`
  ADD PRIMARY KEY (`ser_id`);

--
-- Indexes for table `serviceslot`
--
ALTER TABLE `serviceslot`
  ADD PRIMARY KEY (`idserviceslot`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`users_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `service`
--
ALTER TABLE `service`
  MODIFY `ser_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `serviceslot`
--
ALTER TABLE `serviceslot`
  MODIFY `idserviceslot` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `users_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- Database: `fyp`
--
CREATE DATABASE IF NOT EXISTS `fyp` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `fyp`;

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(11) NOT NULL,
  `name` varchar(255) DEFAULT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `author` varchar(255) DEFAULT NULL,
  `rating` varchar(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `name`, `price`, `author`, `rating`) VALUES
(1, 'The Woke Salaryman Crash Course on Capitalism & Money: Lessons from the World\'s Most Expensive City', 26.30, 'The Woke Salaryman', '4.6'),
(2, 'Thinking, Fast and Slow', 11.90, 'Daniel Kahneman', '4.6'),
(3, 'The Psychology of Money: Timeless lessons on wealth, greed, and happiness', 0.00, 'Morgan Housel', '4.7'),
(4, 'Never Split the Difference: Negotiating as if Your Life Depended on It', 13.40, 'Chris Voss', '4.7'),
(5, 'Hidden Potential: The Science of Achieving Greater Things', 15.20, 'Adam Grant', '4.7'),
(6, 'Atomic Habits: An Easy & Proven Way to Build Good Habits & Break Bad Ones', 16.20, 'James Clear', '4.8'),
(7, 'The Almanack of Naval Ravikant: A Guide to Wealth and Happiness', 14.98, 'Eric Jorgenson', '4.7'),
(8, 'Die With Zero: Getting All You Can from Your Money and Your Life', 18.00, 'Bill Perkins', '4.5'),
(9, 'The First 90 Days: Proven Strategies for Getting Up to Speed Faster and Smarter, Updated and Expanded', 25.40, 'Michael D. Watkins', '4.6'),
(10, 'The 48 Laws of Power', 23.13, 'Robert Greene', '4.7'),
(11, 'The Intelligent Investor', 28.24, 'Benjamin Graham', '4.6'),
(12, 'The Diary of a CEO: The 33 Laws of Business and Life', 40.13, 'Steven Bartlett', '4.7'),
(13, 'Dead in the Water: A True Story of Hijacking, Murder, and a Global Maritime Conspiracy', 30.68, 'Matthew Campbell', '4.6'),
(14, 'Your Complete Guide to Factor-Based Investing: The Way Smart Money Invests Today', 23.37, 'Andrew L Berkin', '4.5'),
(15, 'Unreasonable Hospitality: The Remarkable Power of Giving People More Than They Expect', 17.25, 'Will Guidara', '4.8'),
(16, 'Sharon Sim', 27.14, 'Sharon Sim', 'NULL'),
(17, 'The Daily Stoic: 366 Meditations on Wisdom, Perseverance, and the Art of Living', 17.84, 'Ryan Holiday', '4.8'),
(18, 'Mastery', 22.84, 'Robert Greene', '4.7'),
(19, 'How to Win Friends and Influence People', 12.85, 'Dale Carnegie', '4.7'),
(20, 'Hacking Growth: How Today\'s Fastest-Growing Companies Drive Breakout Success', 31.99, 'Sean Ellis', '4.6'),
(21, '(ISC)2 CISSP Certified Information Systems Security Professional Official Study Guide & Practice Tests Bundle', 82.84, 'Mike Chapple', '4.8'),
(22, 'The World for Sale: Money, Power, and the Traders Who Barter the Earth\'s Resources', 28.89, 'Chief Energy Correspondent Javier Blas', '4.7'),
(23, 'Million Dollar Weekend: The Surprisingly Simple Way to Launch a 7-Figure Business in 48 Hours', 37.37, 'Noah Kagan', '4.9'),
(24, 'The Five Dysfunctions of a Team: A Leadership Fable: A Leadership Fable, 20th Anniversary Edition', 29.62, 'Patrick Lencioni', '4.6'),
(25, 'Start with Why: How Great Leaders Inspire Everyone to Take Action', 17.94, 'Simon Sinek', '4.6'),
(26, 'Can\'t Hurt Me: Master Your Mind and Defy the Odds', 32.41, 'David Goggins', '4.8'),
(27, 'End Times: Elites, Counter-Elites and the Path of Political Disintegration', 21.00, 'Peter Turchin', '4.4'),
(28, 'Mastering Uncertainty: How great founders, entrepreneurs and business leaders thrive in an unpredictable world', 8.85, 'Matt Watkinson', '3.6'),
(29, 'Nudge: The Final Edition', 22.74, 'Richard H. Thaler', '4.6'),
(30, 'Flying Blind: The 737 MAX Tragedy and the Fall of Boeing', 22.04, 'Peter Robison', '4.5'),
(31, 'Dare to Lead: Brave Work. Tough Conversations. Whole Hearts.', 20.00, 'Bren? Brown', '4.7'),
(32, 'Iwoz: Computer Geek to Cult Icon', 27.50, 'Steve Wozniak', '4.5'),
(33, 'Just for Fun: The Story of an Accidental Revolutionary', 23.63, 'Linus Torvalds', '4.7'),
(34, 'Iacocca: An Autobiography', 33.64, 'Lee Iacocca', '4.6'),
(35, 'Same as Ever: A Guide to What Never Changes', 22.87, 'Morgan Housel', '4.5'),
(36, 'Trading: Technical Analysis Masterclass: Master the financial markets', 16.33, 'Rolf Schlotmann', '4.4'),
(37, 'Same as Ever: Timeless Lessons on Risk, Opportunity and Living a Good Life', 17.83, 'Morgan Housel', '4.5'),
(38, 'The Bed of Procrustes: Philosophical and Practical Aphorisms: 4', 34.94, 'Nassim Nicholas Taleb', '4.4'),
(39, '12 Rules for Life: An Antidote to Chaos', 10.90, 'Jordan B. Peterson', '4.7'),
(40, 'Never Split the Difference: Negotiating As If Your Life Depended On It', 15.96, 'Chris Voss', '4.7'),
(41, 'Hacking Growth: How Today\'s Fastest-Growing Companies Drive Breakout Success', 27.00, 'Morgan Brown', '4.6'),
(42, 'Profit First: Transform Your Business from a Cash-Eating Monster to a Money-Making Machine', 20.00, 'Mike Michalowicz', '4.8'),
(43, 'Rich Dad Poor Dad: What the Rich Teach Their Kids About Money That the Poor and Middle Class Do Not!', 10.10, 'Robert T. Kiyosaki', '4.7'),
(44, 'The Laws of Human Nature', 20.28, 'Robert Greene', '4.8'),
(45, 'Think Faster, Talk Smarter: How to Speak Successfully When You\'re Put on the Spot', 20.88, 'Matt Abrahams', '4.6'),
(46, 'Leaders Eat Last: Why Some Teams Pull Together and Others Don\'t', 22.95, 'Simon Sinek', '4.7'),
(47, 'No Rules Rules: Netflix and the Culture of Reinvention', 25.00, 'Reed Hastings', '4.7'),
(48, 'Traction: Get a Grip on Your Business', 24.87, 'Gino Wickman', '4.6'),
(49, 'The Subtle Art of Not Giving a Fuck: A Counterintuitive Approach to Living a Good Life', 17.40, 'Mark Manson', '4.6'),
(50, 'The Daily Stoic: 366 Meditations on Wisdom, Perseverance, and the Art of Living', 17.84, 'NULL', '4.8'),
(51, 'Powerful Leadership Through Coaching: Principles, Practices, and Tools for Leaders and Managers at Every Level', 33.66, 'NULL', '4.7'),
(52, 'Mastering Bitcoin: Programming the Open Blockchain', 76.24, 'NULL', '4.7'),
(53, 'S Vasoo', 48.60, 'NULL', 'NULL'),
(54, 'Sharon Sim', 27.14, 'NULL', 'NULL'),
(55, 'Any Happy Returns: Structural Changes and Super Cycles in Markets', 44.85, 'NULL', '5'),
(56, 'The Business Case for AI: A Leader\'s Guide to AI Strategies, Best Practices & Real-World Applications', 23.27, 'NULL', '4.4'),
(57, 'Paris to the Moon', 26.15, 'NULL', '4.4'),
(58, 'The Diary of a CEO: The 33 Laws of Business and Life', 40.13, 'NULL', '4.7'),
(59, 'Dead in the Water: A True Story of Hijacking, Murder, and a Global Maritime Conspiracy', 30.68, 'NULL', '4.6'),
(60, 'Mastery', 22.84, 'NULL', '4.7'),
(61, 'DisneyWar', 29.06, 'NULL', '4.6'),
(62, 'Nicolas Stephan', 65.88, 'NULL', 'NULL'),
(63, 'Nudge: The Final Edition', 34.98, 'NULL', '4.6'),
(64, 'Think Again: The Power of Knowing What You Don\'t Know', 24.18, 'NULL', '4.7'),
(65, 'Your Complete Guide to Factor-Based Investing: The Way Smart Money Invests Today', 23.37, 'NULL', '4.5'),
(66, 'Leading: Lessons in leadership from the legendary Manchester United manager', 25.34, 'NULL', '4.6'),
(67, 'Drunk Tank Pink: And Other Unexpected Forces That Shape How We Think, Feel, and Behave', 30.00, 'NULL', '4.4'),
(68, 'Unreasonable Hospitality: The Remarkable Power of Giving People More Than They Expect', 17.25, 'NULL', '4.8'),
(69, 'Principle-Centered Leadership', 24.83, 'NULL', '4.6'),
(70, 'The Enneagram Development Guide', 60.91, 'NULL', '4.7'),
(71, 'Nothing But Net: 10 Timeless Stock-Picking Lessons from One of Wall Street?s Top Tech Analysts', 41.01, 'NULL', '4.3'),
(72, 'A Sun Tzu\'s Art of War for Women: Strategies for Winning without Conflict - Revised with a New Introduction', 22.47, 'NULL', '4.5'),
(73, 'A New Way to Think: Your Guide to Superior Management Effectiveness', 32.00, 'NULL', '4.7'),
(74, '(ISC)2 CISSP Certified Information Systems Security Professional Official Study Guide & Practice Tests Bundle', 82.62, 'NULL', '4.8'),
(75, 'Million Dollar Weekend: The Surprisingly Simple Way to Launch a 7-Figure Business in 48 Hours', 37.37, 'NULL', '4.9'),
(76, 'Hacking Growth: How Today\'s Fastest-Growing Companies Drive Breakout Success', 31.99, 'NULL', '4.6'),
(77, 'The Five Dysfunctions of a Team: A Leadership Fable: A Leadership Fable, 20th Anniversary Edition', 29.62, 'NULL', '4.6'),
(78, 'Can\'t Hurt Me: Master Your Mind and Defy the Odds', 32.41, 'NULL', '4.8'),
(79, 'The World for Sale: Money, Power, and the Traders Who Barter the Earth\'s Resources', 28.89, 'NULL', '4.7'),
(80, 'Dare to Lead: Brave Work. Tough Conversations. Whole Hearts.', 20.00, 'NULL', '4.7'),
(81, 'End Times: Elites, Counter-Elites and the Path of Political Disintegration', 21.00, 'NULL', '4.4'),
(82, 'Same as Ever: A Guide to What Never Changes', 22.87, 'NULL', '4.5'),
(83, 'Never Split the Difference: Negotiating As If Your Life Depended On It', 15.96, 'NULL', '4.7'),
(84, 'The Laws of Human Nature', 20.28, 'NULL', '4.8'),
(85, 'Mastering Uncertainty: How great founders, entrepreneurs and business leaders thrive in an unpredictable world', 8.85, 'NULL', '3.6'),
(86, '12 Rules for Life: An Antidote to Chaos', 10.90, 'NULL', '4.7'),
(87, 'Flying Blind: The 737 MAX Tragedy and the Fall of Boeing', 22.04, 'NULL', '4.5'),
(88, 'Think Faster, Talk Smarter: How to Speak Successfully When You\'re Put on the Spot', 20.88, 'NULL', '4.6'),
(89, 'Iwoz: Computer Geek to Cult Icon', 27.50, 'NULL', '4.5'),
(90, 'Just for Fun: The Story of an Accidental Revolutionary', 23.63, 'NULL', '4.7'),
(91, 'Iacocca: An Autobiography', 33.64, 'NULL', '4.6'),
(92, 'Rich Dad Poor Dad: What the Rich Teach Their Kids About Money That the Poor and Middle Class Do Not!', 10.10, 'NULL', '4.7'),
(93, 'Feel-Good Productivity: How to Achieve More of the Things That Matter', 20.05, 'NULL', '4.7'),
(94, 'Same as Ever: Timeless Lessons on Risk, Opportunity and Living a Good Life', 17.83, 'NULL', '4.5'),
(95, 'Trading: Technical Analysis Masterclass: Master the financial markets', 16.33, 'NULL', '4.4'),
(96, 'Hacking Growth: How Today\'s Fastest-Growing Companies Drive Breakout Success', 27.00, 'NULL', '4.6'),
(97, 'No Rules Rules: Netflix and the Culture of Reinvention', 25.00, 'NULL', '4.7'),
(98, 'Profit First: Transform Your Business from a Cash-Eating Monster to a Money-Making Machine', 20.00, 'NULL', '4.8'),
(99, 'The Bed of Procrustes: Philosophical and Practical Aphorisms: 4', 34.94, 'NULL', '4.4');

-- --------------------------------------------------------

--
-- Table structure for table `shopping_cart`
--

CREATE TABLE `shopping_cart` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `user_type` enum('user','admin') NOT NULL,
  `email` varchar(100) NOT NULL,
  `full_name` varchar(100) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `user_type`, `email`, `full_name`) VALUES
(1, 'wj', '$2y$10$7cAyvKlbAtOoFE6BMP1p0e2JMlord3UG8h7N6fsd5a2Ad86rckunK', 'user', 'weijie@gmail.com', 'Wei Jie'),
(16, 'jr', '$2y$10$pu6IgztxeRt7hi.Bwn19yezjb8EF8fjJyScyhKPXGpzOj0mUc/2XK', 'user', 'jr@gmail.com', 'Jun Ren'),
(17, 'asd', '$2y$10$v4UbhmXo2LGd3FFQlTESoOOEyRn2rMgc76rKDLIRL84w.xXeaIy8a', 'admin', 'asd@asd.com', 'asd');

-- --------------------------------------------------------

--
-- Table structure for table `user_details`
--

CREATE TABLE `user_details` (
  `id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `age` int(11) DEFAULT NULL,
  `gender` enum('male','female','other') DEFAULT NULL,
  `occupation` varchar(255) DEFAULT NULL,
  `genre` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_details`
--

INSERT INTO `user_details` (`id`, `username`, `age`, `gender`, `occupation`, `genre`) VALUES
(2, 'jr', 18, 'male', 'doctor', 'Romance'),
(3, 'wj', NULL, NULL, NULL, NULL),
(4, 'asd', 25, 'male', 'doctor', 'Romance');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `shopping_cart`
--
ALTER TABLE `shopping_cart`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`),
  ADD KEY `product_id` (`product_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_details`
--
ALTER TABLE `user_details`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=100;

--
-- AUTO_INCREMENT for table `shopping_cart`
--
ALTER TABLE `shopping_cart`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `user_details`
--
ALTER TABLE `user_details`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `shopping_cart`
--
ALTER TABLE `shopping_cart`
  ADD CONSTRAINT `shopping_cart_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  ADD CONSTRAINT `shopping_cart_ibfk_2` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`);
--
-- Database: `phpmyadmin`
--
CREATE DATABASE IF NOT EXISTS `phpmyadmin` DEFAULT CHARACTER SET utf8 COLLATE utf8_bin;
USE `phpmyadmin`;

-- --------------------------------------------------------

--
-- Table structure for table `pma__bookmark`
--

CREATE TABLE `pma__bookmark` (
  `id` int(10) UNSIGNED NOT NULL,
  `dbase` varchar(255) NOT NULL DEFAULT '',
  `user` varchar(255) NOT NULL DEFAULT '',
  `label` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `query` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Bookmarks';

-- --------------------------------------------------------

--
-- Table structure for table `pma__central_columns`
--

CREATE TABLE `pma__central_columns` (
  `db_name` varchar(64) NOT NULL,
  `col_name` varchar(64) NOT NULL,
  `col_type` varchar(64) NOT NULL,
  `col_length` text DEFAULT NULL,
  `col_collation` varchar(64) NOT NULL,
  `col_isNull` tinyint(1) NOT NULL,
  `col_extra` varchar(255) DEFAULT '',
  `col_default` text DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Central list of columns';

-- --------------------------------------------------------

--
-- Table structure for table `pma__column_info`
--

CREATE TABLE `pma__column_info` (
  `id` int(5) UNSIGNED NOT NULL,
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `column_name` varchar(64) NOT NULL DEFAULT '',
  `comment` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `mimetype` varchar(255) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '',
  `transformation` varchar(255) NOT NULL DEFAULT '',
  `transformation_options` varchar(255) NOT NULL DEFAULT '',
  `input_transformation` varchar(255) NOT NULL DEFAULT '',
  `input_transformation_options` varchar(255) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Column information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__designer_settings`
--

CREATE TABLE `pma__designer_settings` (
  `username` varchar(64) NOT NULL,
  `settings_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Settings related to Designer';

-- --------------------------------------------------------

--
-- Table structure for table `pma__export_templates`
--

CREATE TABLE `pma__export_templates` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL,
  `export_type` varchar(10) NOT NULL,
  `template_name` varchar(64) NOT NULL,
  `template_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved export templates';

-- --------------------------------------------------------

--
-- Table structure for table `pma__favorite`
--

CREATE TABLE `pma__favorite` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Favorite tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__history`
--

CREATE TABLE `pma__history` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db` varchar(64) NOT NULL DEFAULT '',
  `table` varchar(64) NOT NULL DEFAULT '',
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp(),
  `sqlquery` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='SQL history for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__navigationhiding`
--

CREATE TABLE `pma__navigationhiding` (
  `username` varchar(64) NOT NULL,
  `item_name` varchar(64) NOT NULL,
  `item_type` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Hidden items of navigation tree';

-- --------------------------------------------------------

--
-- Table structure for table `pma__pdf_pages`
--

CREATE TABLE `pma__pdf_pages` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `page_nr` int(10) UNSIGNED NOT NULL,
  `page_descr` varchar(50) CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='PDF relation pages for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__recent`
--

CREATE TABLE `pma__recent` (
  `username` varchar(64) NOT NULL,
  `tables` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Recently accessed tables';

-- --------------------------------------------------------

--
-- Table structure for table `pma__relation`
--

CREATE TABLE `pma__relation` (
  `master_db` varchar(64) NOT NULL DEFAULT '',
  `master_table` varchar(64) NOT NULL DEFAULT '',
  `master_field` varchar(64) NOT NULL DEFAULT '',
  `foreign_db` varchar(64) NOT NULL DEFAULT '',
  `foreign_table` varchar(64) NOT NULL DEFAULT '',
  `foreign_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Relation table';

-- --------------------------------------------------------

--
-- Table structure for table `pma__savedsearches`
--

CREATE TABLE `pma__savedsearches` (
  `id` int(5) UNSIGNED NOT NULL,
  `username` varchar(64) NOT NULL DEFAULT '',
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `search_name` varchar(64) NOT NULL DEFAULT '',
  `search_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Saved searches';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_coords`
--

CREATE TABLE `pma__table_coords` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `pdf_page_number` int(11) NOT NULL DEFAULT 0,
  `x` float UNSIGNED NOT NULL DEFAULT 0,
  `y` float UNSIGNED NOT NULL DEFAULT 0
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table coordinates for phpMyAdmin PDF output';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_info`
--

CREATE TABLE `pma__table_info` (
  `db_name` varchar(64) NOT NULL DEFAULT '',
  `table_name` varchar(64) NOT NULL DEFAULT '',
  `display_field` varchar(64) NOT NULL DEFAULT ''
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Table information for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__table_uiprefs`
--

CREATE TABLE `pma__table_uiprefs` (
  `username` varchar(64) NOT NULL,
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `prefs` text NOT NULL,
  `last_update` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Tables'' UI preferences';

-- --------------------------------------------------------

--
-- Table structure for table `pma__tracking`
--

CREATE TABLE `pma__tracking` (
  `db_name` varchar(64) NOT NULL,
  `table_name` varchar(64) NOT NULL,
  `version` int(10) UNSIGNED NOT NULL,
  `date_created` datetime NOT NULL,
  `date_updated` datetime NOT NULL,
  `schema_snapshot` text NOT NULL,
  `schema_sql` text DEFAULT NULL,
  `data_sql` longtext DEFAULT NULL,
  `tracking` set('UPDATE','REPLACE','INSERT','DELETE','TRUNCATE','CREATE DATABASE','ALTER DATABASE','DROP DATABASE','CREATE TABLE','ALTER TABLE','RENAME TABLE','DROP TABLE','CREATE INDEX','DROP INDEX','CREATE VIEW','ALTER VIEW','DROP VIEW') DEFAULT NULL,
  `tracking_active` int(1) UNSIGNED NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Database changes tracking for phpMyAdmin';

-- --------------------------------------------------------

--
-- Table structure for table `pma__userconfig`
--

CREATE TABLE `pma__userconfig` (
  `username` varchar(64) NOT NULL,
  `timevalue` timestamp NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `config_data` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User preferences storage for phpMyAdmin';

--
-- Dumping data for table `pma__userconfig`
--

INSERT INTO `pma__userconfig` (`username`, `timevalue`, `config_data`) VALUES
('root', '2019-10-21 13:37:09', '{\"Console\\/Mode\":\"collapse\"}');

-- --------------------------------------------------------

--
-- Table structure for table `pma__usergroups`
--

CREATE TABLE `pma__usergroups` (
  `usergroup` varchar(64) NOT NULL,
  `tab` varchar(64) NOT NULL,
  `allowed` enum('Y','N') NOT NULL DEFAULT 'N'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='User groups with configured menu items';

-- --------------------------------------------------------

--
-- Table structure for table `pma__users`
--

CREATE TABLE `pma__users` (
  `username` varchar(64) NOT NULL,
  `usergroup` varchar(64) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin COMMENT='Users and their assignments to user groups';

--
-- Indexes for dumped tables
--

--
-- Indexes for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `pma__central_columns`
--
ALTER TABLE `pma__central_columns`
  ADD PRIMARY KEY (`db_name`,`col_name`);

--
-- Indexes for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `db_name` (`db_name`,`table_name`,`column_name`);

--
-- Indexes for table `pma__designer_settings`
--
ALTER TABLE `pma__designer_settings`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_user_type_template` (`username`,`export_type`,`template_name`);

--
-- Indexes for table `pma__favorite`
--
ALTER TABLE `pma__favorite`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__history`
--
ALTER TABLE `pma__history`
  ADD PRIMARY KEY (`id`),
  ADD KEY `username` (`username`,`db`,`table`,`timevalue`);

--
-- Indexes for table `pma__navigationhiding`
--
ALTER TABLE `pma__navigationhiding`
  ADD PRIMARY KEY (`username`,`item_name`,`item_type`,`db_name`,`table_name`);

--
-- Indexes for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  ADD PRIMARY KEY (`page_nr`),
  ADD KEY `db_name` (`db_name`);

--
-- Indexes for table `pma__recent`
--
ALTER TABLE `pma__recent`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__relation`
--
ALTER TABLE `pma__relation`
  ADD PRIMARY KEY (`master_db`,`master_table`,`master_field`),
  ADD KEY `foreign_field` (`foreign_db`,`foreign_table`);

--
-- Indexes for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `u_savedsearches_username_dbname` (`username`,`db_name`,`search_name`);

--
-- Indexes for table `pma__table_coords`
--
ALTER TABLE `pma__table_coords`
  ADD PRIMARY KEY (`db_name`,`table_name`,`pdf_page_number`);

--
-- Indexes for table `pma__table_info`
--
ALTER TABLE `pma__table_info`
  ADD PRIMARY KEY (`db_name`,`table_name`);

--
-- Indexes for table `pma__table_uiprefs`
--
ALTER TABLE `pma__table_uiprefs`
  ADD PRIMARY KEY (`username`,`db_name`,`table_name`);

--
-- Indexes for table `pma__tracking`
--
ALTER TABLE `pma__tracking`
  ADD PRIMARY KEY (`db_name`,`table_name`,`version`);

--
-- Indexes for table `pma__userconfig`
--
ALTER TABLE `pma__userconfig`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `pma__usergroups`
--
ALTER TABLE `pma__usergroups`
  ADD PRIMARY KEY (`usergroup`,`tab`,`allowed`);

--
-- Indexes for table `pma__users`
--
ALTER TABLE `pma__users`
  ADD PRIMARY KEY (`username`,`usergroup`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `pma__bookmark`
--
ALTER TABLE `pma__bookmark`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__column_info`
--
ALTER TABLE `pma__column_info`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__export_templates`
--
ALTER TABLE `pma__export_templates`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__history`
--
ALTER TABLE `pma__history`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__pdf_pages`
--
ALTER TABLE `pma__pdf_pages`
  MODIFY `page_nr` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pma__savedsearches`
--
ALTER TABLE `pma__savedsearches`
  MODIFY `id` int(5) UNSIGNED NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
